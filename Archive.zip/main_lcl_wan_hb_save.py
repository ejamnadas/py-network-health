import dtma_ntw_health_tasks as tasks
import variables as var

tasks.hb_save(var.getProperty())