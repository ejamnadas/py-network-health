pgUser = 'ejamnadas'
pgWp = 'N33nte*'
pgHost = '35.184.12.134'
pgPort = '5432'

def getProperty():
  return 'LQS';